# เช็คลิสต์ + ส่วนประกอบเพิ่มเติม

## เช็คลิสต์ก่อนบอกว่าเสร็จ

- [ ] ยิงจริงแล้ว: ไม่มี key → 401 · key ผิด → 401 · key ถูก → 200
- [ ] ทุกค่าที่มาจาก DB ผ่าน `esc()` (ไล่ดูทีละ `${` ในไฟล์ render)
- [ ] แหล่งข้อมูลตัวใดตัวหนึ่งล่ม → หน้ายังขึ้น 200 พร้อมข้อความบอกว่าต้องทำอะไร
- [ ] ฟอร์ม POST ทุกอันมี `${gate.keyInput()}` และ redirect กลับพร้อม `ok=`/`err=`
- [ ] ปุ่มลบมี `confirm()` ที่บอกเป็นภาษาไทยว่าอะไรจะหาย/ไม่หาย
- [ ] ย่อจอ 375px แล้วยังอ่านได้ (stats 2 คอลัมน์, panels 1 คอลัมน์, ตารางเลื่อนแนวนอนได้)
- [ ] เพิ่มหน้าใหม่แล้วเพิ่มแถวใน `adminNav.TABS` ด้วย (ไม่งั้นเข้าถึงได้เฉพาะคนที่รู้ URL)
- [ ] `ADMIN_KEY` อยู่ใน `.env` + `.env.example` และไม่โผล่ใน git
- [ ] footer เขียนที่มาของตัวเลข + สิ่งที่ตัวเลขไม่ได้รวม

## ส่วนประกอบเพิ่มเติม (คัดลอกไปใช้)

### แถบ progress + สีตามระดับ
```js
const pct = (used / limit) * 100;
const color = pct >= 85 ? '#E0483E' : pct >= 60 ? '#F39C12' : '#06C755';
`<div class="big">${used}<span class="u"> / ${limit}</span></div>${bar(pct, color)}`
```
เกณฑ์ 60/85% ใช้ซ้ำได้ทุกที่ (โควต้า, งบ, พื้นที่) — สีต้องแปลว่าอย่างเดียวกันทั้งระบบ

### กราฟแท่งรายวัน (ไม่ต้องใช้ไลบรารี)
```js
const bars = days.map((x) => `<div class="col" title="${esc(x.label)}: ${x.calls}">
  <div class="colbar" style="height:${Math.round((x.calls / maxDay) * 100)}%"></div>
  <div class="cap">${esc(x.label)}</div></div>`).join('');
```
`maxDay` ต้อง `Math.max(1, ...)` เสมอ — ไม่งั้นวันแรกที่ยังไม่มีข้อมูลจะหาร 0 ได้ `NaN%`

### ชิปกรองฝั่ง browser
```html
<button class="chip active" data-f="all">ทั้งหมด</button>
<button class="chip" data-f="<id>">ชื่อ (3)</button>
```
```js
document.querySelectorAll('.gfilter .chip').forEach(function (b) {
  b.addEventListener('click', function () {
    document.querySelectorAll('.gfilter .chip').forEach(function (x) { x.classList.remove('active'); });
    b.classList.add('active');
    var f = b.getAttribute('data-f');
    document.querySelectorAll('.gal .gcard').forEach(function (c) {
      c.style.display = (f === 'all' || c.getAttribute('data-owner') === f) ? '' : 'none';
    });
  });
});
```
โชว์ชิปเฉพาะตอนมีเจ้าของมากกว่า 1 ราย ไม่งั้นเป็นปุ่มที่กดแล้วไม่มีอะไรเกิดขึ้น

### แกลเลอรีไฟล์แนบ
- รูปเสิร์ฟผ่าน route ของเราเอง `/admin/file/:id?key=...` (ห้ามลิงก์ตรงไป storage ที่ต้องล็อกอิน)
- ใส่ `loading="lazy"` ทุกรูป
- **PDF แสดงใน `<img>` ไม่ได้** ทำเป็นการ์ด "📄 เปิด PDF" ที่เป็น `<a target="_blank" rel="noopener">` แทน
- `onerror` ของ `<img>` ที่อยู่ใน template literal ต้อง escape quote ซ้อน:
  `onerror="this.parentElement.innerHTML='<div class=\\'noimg\\'>เปิดรูปไม่ได้</div>'"`

### ตารางที่ยาวมาก
```js
const TOP_ROWS = 15;
// แถวที่ i >= TOP_ROWS ใส่ class="hid" + ทุกแถวมี data-hay
// ปุ่ม "แสดงทั้งหมด" toggle expanded, ช่องค้นหา override การย่อ
```
กฎที่ต้องรักษา: **มีคำค้น = โชว์ทุกแถวที่ตรงเสมอ** (ไม่งั้นค้นเจอแต่แถวที่ 30 ไม่ขึ้น) และซ่อนปุ่ม
"แสดงทั้งหมด" ตอนกำลังค้น

### ตัวเลขในตาราง
ใส่ `class="num"` (มี `font-variant-numeric:tabular-nums` แล้ว) — ตัวเลขไม่ขยับตอนรีเฟรช
เงินใช้ `.toFixed(2)` เสมอ, จำนวนใช้ `.toLocaleString()`

## เมื่อผู้ใช้ขอ "หน้าใหม่" เพิ่มในระบบเดิม

1. สร้าง `src/<ชื่อ>Page.js` — คัดลอกโครงจาก `adminPage.js` (page/render สองชั้น)
2. เพิ่มแถวใน `adminNav.TABS`
3. เพิ่ม `app.get` + `app.post` ใน `index.js` โดยขึ้นต้นด้วย `if (!gate.requireAdmin(req, res)) return;`
4. CSS เฉพาะหน้าวาง **หลัง** `${ui.BASE_CSS}` เท่านั้น — อย่าไปแก้ `uiTheme.js` เพื่อหน้าเดียว
   (แก้ที่นั่นเมื่อจะเปลี่ยนทั้งระบบเท่านั้น)
