// หน้า /admin — โครงหน้า dashboard (คัดลอกไปแล้วแก้ต่อได้เลย)
// โครงสร้างบังคับ: page() = ชั้นดึงข้อมูล · render(m) = ชั้นสร้าง HTML ล้วน (ไม่ await ไม่แตะ DB)
// แยกสองชั้นนี้ไว้เสมอ — จะเทสต์ render ด้วยข้อมูลปลอมได้โดยไม่ต้องมี DB
const ui = require('./uiTheme');
const nav = require('./adminNav');
const gate = require('./adminGate');

// ---------- helpers ----------
// esc ต้องครอบ "ทุกค่าที่มาจาก DB/ผู้ใช้" ก่อนยัดลง HTML — ไม่มีข้อยกเว้น
function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}
const n = (v) => Number(v || 0).toLocaleString();
const initials = (name) => esc(String(name || '?').trim().slice(0, 2).toUpperCase());

function bar(pct, color) {
  return `<div class="bar"><span style="width:${Math.max(2, Math.min(100, pct || 0))}%;background:${color}"></span></div>`;
}
function statCard(icon, label, value, sub, accent) {
  return `<div class="stat">
    <div class="ic" style="background:${accent}1a;color:${accent}">${icon}</div>
    <div class="meta"><div class="lab">${esc(label)}</div><div class="val">${value}</div>${sub ? `<div class="sub">${sub}</div>` : ''}</div>
  </div>`;
}

const TOP_ROWS = 15; // ตารางยาว → โชว์เท่านี้ก่อน ที่เหลือซ่อนไว้ให้กดกาง

/**
 * ชั้นดึงข้อมูล — ยิงทุก query พร้อมกัน และ "ทุกตัวต้องมี .catch เป็นของตัวเอง"
 * เพื่อให้แหล่งข้อมูลเดียวล่มแล้วหน้าไม่ 500 ทั้งหน้า
 * คืน null (ไม่ใช่ []) เมื่อ "ตาราง/บริการยังไม่พร้อม" เพื่อให้ render แยกได้ว่า
 * "ยังไม่ได้ตั้งค่า" ≠ "ตั้งค่าแล้วแต่ยังไม่มีข้อมูล"
 */
async function page(deps, query = {}) {
  const [rows, totalUsers, health] = await Promise.all([
    deps.listRows().catch(() => null),
    deps.countUsers().catch(() => null),
    deps.health().catch(() => null),
  ]);

  const available = Array.isArray(rows);
  const data = available ? rows : [];

  // รวมยอดในชั้นนี้ ไม่ใช่ในชั้น render
  const byDay = new Map();
  let calls = 0;
  for (const r of data) {
    calls += 1;
    const k = String(r.createdAt || '').slice(0, 10);
    byDay.set(k, (byDay.get(k) || 0) + 1);
  }
  const days = [...byDay.entries()].sort().map(([k, v]) => ({ label: k.slice(8), calls: v }));

  return render({
    query,
    available,
    // ยอด "ผู้ใช้ทั้งหมด" ต้องนับจากตารางผู้ใช้จริง — นับจาก log ได้แค่คนที่ใช้งานในช่วงนั้น
    totalUsers: totalUsers == null ? data.length : totalUsers,
    usersExact: totalUsers != null,
    calls,
    days,
    maxDay: Math.max(1, ...days.map((d) => d.calls)),
    today: days.length ? days[days.length - 1].calls : 0,
    health,
    rows: [...data].sort((a, b) => (b.calls || 0) - (a.calls || 0)),
    nowLabel: deps.nowLabel(),
  });
}

/** ชั้นสร้าง HTML — pure string builder */
function render(m) {
  const warn = m.available ? '' :
    `<div class="warn">⚠️ ยังไม่มีตารางข้อมูล — รัน migration ก่อน แล้วสถิติจะขึ้นที่นี่ (ส่วนอื่นของหน้ายังใช้ได้ปกติ)</div>`;

  const dayBars = m.days.length
    ? m.days.map((x) => `<div class="col" title="${esc(x.label)}: ${n(x.calls)}">
        <div class="colbar" style="height:${Math.round((x.calls / m.maxDay) * 100)}%"></div>
        <div class="cap">${esc(x.label)}</div></div>`).join('')
    : `<div class="dim">ยังไม่มีข้อมูล</div>`;

  // data-hay = ข้อความที่ให้ช่องค้นหาฝั่ง browser ค้น (ไม่ต้องยิงเซิร์ฟเวอร์ใหม่)
  const CONFIRM = 'ลบรายการนี้?\\n\\nสิ่งที่หาย:\\n- ประวัติการใช้งาน\\n- ค่าที่ตั้งไว้\\n\\nกู้คืนไม่ได้';
  const bodyRows = m.rows.length
    ? m.rows.map((r, i) => `<tr class="urow${i >= TOP_ROWS ? ' hid' : ''}" data-hay="${esc(String(r.name || '').toLowerCase())}">
        <td><div class="who"><span class="av">${initials(r.name)}</span><div class="nm">${esc(r.name)}</div></div></td>
        <td class="num">${n(r.calls)}</td>
        <td class="num dim">${esc(r.last || '-')}</td>
        <td class="num"><form method="post" action="/admin/row/delete" onsubmit="return confirm('${CONFIRM}')">
          ${gate.keyInput()}<input type="hidden" name="id" value="${esc(r.id)}">
          <button type="submit" class="btn danger" style="padding:4px 10px;font-size:11.5px">🗑️ ลบ</button>
        </form></td>
      </tr>`).join('')
    : `<tr><td colspan="4" class="empty">ยังไม่มีข้อมูล</td></tr>`;

  return `<!doctype html><html lang="th"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="60">
<title>Dashboard</title>
${ui.FONT}
<style>
  ${ui.BASE_CSS}
  ${nav.CSS}
  /* auto-fit + align-items:start — การ์ดจำนวนคี่ไม่ตกแถวเดี่ยว และการ์ดเตี้ยไม่ถูกยืดตามการ์ดสูง */
  .panels{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:14px;margin-bottom:16px;align-items:start}
  @media(max-width:760px){.panels{grid-template-columns:1fr}}
  .big{font-size:27px;font-weight:700}.big .u{font-size:15px;color:var(--muted);font-weight:500}
  .bar{height:8px;background:#EDF1F9;border-radius:99px;overflow:hidden;margin:9px 0 7px}
  .bar span{display:block;height:100%;border-radius:99px;transition:width .4s}
  .dim{color:var(--muted);font-size:12.5px}
  .chart{display:flex;align-items:flex-end;gap:5px;height:130px;padding-top:8px}
  .col{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;height:100%;gap:5px}
  .colbar{width:70%;min-height:3px;background:linear-gradient(180deg,#5B8DF0,#2D6CDF);border-radius:5px 5px 0 0;transition:height .4s}
  .col .cap{font-size:10px;color:var(--muted)}
  .who{display:flex;align-items:center;gap:10px}
  .av{width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,#5B8DF0,#2D6CDF);color:#fff;display:grid;place-items:center;font-size:12px;font-weight:700;flex:0 0 auto}
  .nm{font-weight:600}
  .empty{text-align:center;color:var(--muted);padding:28px}
  .thbar{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}
  .cnt{font-weight:500;font-size:12.5px;color:var(--muted);margin-left:6px}
  /* ต้องเขียน input[type=search].srch — ถ้าเขียนแค่ .srch จะแพ้ selector input[type=search] ใน BASE_CSS
     (specificity สูงกว่า) แล้วช่องค้นหาจะกว้าง 100% ดันหัวตารางตกบรรทัด */
  input[type=search].srch{width:auto;min-width:220px;font-size:13px;padding:7px 12px}
  tr.hid{display:none}
  .morebar{display:flex;align-items:center;gap:12px;flex-wrap:wrap;padding:12px 16px;border-top:1px solid var(--line)}
  /* การ์ดพับเก็บ — ของที่ใช้นานๆ ครั้ง (ฟอร์มตั้งค่า/ล็อก) ไม่ควรกินพื้นที่หัวหน้า */
  .fold>summary{cursor:pointer;list-style:none;display:flex;align-items:center;gap:8px}
  .fold>summary::-webkit-details-marker{display:none}
  .fold>summary::before{content:'▸';color:var(--muted);font-size:13px;transition:.15s}
  .fold[open]>summary::before{transform:rotate(90deg)}
</style></head>
<body>
  <div class="hero"><div class="wrap"><div class="hbar">
    <div><h1>📊 Dashboard</h1><div class="hsub">อัปเดต ${esc(m.nowLabel)}</div></div>
    <span class="pill"><span class="live"></span>รีเฟรชอัตโนมัติทุก 60 วิ</span>
  </div>${nav.html('dash', gate.ADMIN_KEY)}</div></div>

  <div class="wrap lift">
    ${gate.flashHtml(m.query, esc)}
    ${warn}
    <div class="stats">
      ${statCard('👥', 'ผู้ใช้ทั้งหมด', n(m.totalUsers), m.usersExact ? '' : 'ประมาณจาก log', '#2D6CDF')}
      ${statCard('⚡', 'การเรียกใช้', n(m.calls), 'ช่วงที่เลือก', '#7C4DFF')}
      ${statCard('💚', 'สถานะระบบ', m.health ? esc(m.health.label) : '—', m.health ? '' : 'ตรวจไม่ได้', '#06C755')}
      ${statCard('📄', 'แถวข้อมูล', n(m.rows.length), '', '#F39C12')}
    </div>

    <div class="panels">
      <div class="panel"><h3>📈 การใช้รายวัน</h3><div class="chart">${dayBars}</div></div>
      <div class="panel"><h3>ℹ️ สรุป</h3>
        <div class="big">${n(m.today)}<span class="u"> / ${n(m.maxDay)} ครั้ง (สูงสุดต่อวัน)</span></div>
        ${/* แถบต้องเทียบกับอะไรที่มีความหมายเสมอ — เทียบกับตัวเลขที่คิดขึ้นเองจะดูเหมือนบั๊ก */''}
        ${bar((m.today / m.maxDay) * 100, m.today >= m.maxDay ? '#F39C12' : '#2D6CDF')}
        <div class="dim">รวม ${n(m.calls)} ครั้ง · ผู้ใช้ ${n(m.totalUsers)} คน</div>
      </div>
    </div>

    <div class="tablecard">
      <div class="th thbar">
        <span>👤 รายละเอียด <span class="cnt">${n(m.rows.length)} รายการ</span></span>
        <input id="usearch" class="srch" type="search" placeholder="ค้นหา…" autocomplete="off">
      </div>
      <table>
        <thead><tr><th>ชื่อ</th><th class="num">ครั้ง</th><th class="num">ล่าสุด</th><th class="num">จัดการ</th></tr></thead>
        <tbody id="ubody">${bodyRows}</tbody>
      </table>
      ${m.rows.length > TOP_ROWS ? `<div class="morebar">
        <button type="button" id="umore" class="btn gray">แสดงทั้งหมด (${n(m.rows.length)})</button>
        <span id="ucount" class="dim">แสดง ${TOP_ROWS} อันดับแรก</span>
      </div>` : ''}
    </div>

    <details class="panel fold" style="margin-top:16px">
      <summary><h3>⚙️ ตั้งค่า (ใช้นานๆ ครั้ง)</h3></summary>
      <form method="post" action="/admin/settings/save" style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap">
        ${gate.keyInput()}
        <input type="text" name="value" placeholder="ค่าที่ต้องการตั้ง" style="flex:1;min-width:180px">
        <button class="btn" type="submit">บันทึก</button>
      </form>
    </details>

    <footer>หน้านี้ล็อกด้วย ADMIN_KEY เท่านั้น (ไม่ใช่ระบบล็อกอินจริง) — อย่าวางข้อมูลที่หลุดไม่ได้ไว้ที่นี่</footer>
  </div>
  <script>
    // ตาราง: ย่อไว้ + ค้นหาฝั่ง browser (มีคำค้น = โชว์ทุกแถวที่ตรง ไม่สนสถานะย่อ)
    (function () {
      var rows = [].slice.call(document.querySelectorAll('#ubody .urow'));
      var more = document.getElementById('umore');
      var cnt = document.getElementById('ucount');
      var box = document.getElementById('usearch');
      if (!rows.length) return;
      var TOP = ${TOP_ROWS};
      var expanded = false;
      function draw() {
        var q = (box && box.value || '').trim().toLowerCase();
        var shown = 0;
        rows.forEach(function (tr, i) {
          var hit = !q || (tr.getAttribute('data-hay') || '').indexOf(q) !== -1;
          var show = hit && (q || expanded || i < TOP);
          tr.classList.toggle('hid', !show);
          if (show) shown++;
        });
        if (cnt) cnt.textContent = q ? ('พบ ' + shown + ' รายการ') : (expanded ? ('แสดงครบ ' + rows.length) : ('แสดง ' + TOP + ' อันดับแรก'));
        if (more) more.style.display = q ? 'none' : '';
      }
      if (more) more.addEventListener('click', function () {
        expanded = !expanded;
        more.textContent = expanded ? 'ย่อกลับ' : ('แสดงทั้งหมด (' + rows.length + ')');
        draw();
      });
      if (box) box.addEventListener('input', draw);
      draw();
    })();
  </script>
</body></html>`;
}

module.exports = { page, render, esc, statCard, bar };
