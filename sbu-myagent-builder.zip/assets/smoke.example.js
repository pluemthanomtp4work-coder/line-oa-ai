// smoke test หน้า admin — ยิงจริงผ่าน HTTP ไม่ต้องมี DB
// รัน: node smoke.example.js   (ต้องมี express ใน node_modules ของโปรเจกต์)
// แก้ path ของ require ให้ตรงโปรเจกต์ปลายทาง แล้วเก็บไว้เป็นเทสประจำ
process.env.ADMIN_KEY = 'test-key-123';

const express = require('express');
const gate = require('../src/adminGate');
const dash = require('../src/adminPage');

// ข้อมูลปลอม: ตั้งใจใส่ payload XSS + แถวเกิน TOP_ROWS
const deps = {
  listRows: async () => ([
    { id: 'a1', name: '<img src=x onerror=alert(1)>', calls: 9, last: '-', createdAt: '2026-08-11T03:00:00Z' },
    ...Array.from({ length: 20 }, (_, i) => ({ id: 'u' + i, name: 'ผู้ใช้ ' + i, calls: 20 - i, last: '-', createdAt: '2026-08-12T03:00:00Z' })),
  ]),
  countUsers: async () => 370,
  health: async () => ({ label: 'ปกติ' }),
  nowLabel: () => '12 ส.ค. 69 10:00',
};
// จำลองตารางยังไม่ถูกสร้าง → หน้าต้องไม่ 500
const depsDown = { ...deps, listRows: async () => { throw new Error('relation does not exist'); } };

const app = express();
app.use(express.urlencoded({ extended: false }));
app.get('/admin', async (req, res) => { if (!gate.requireAdmin(req, res)) return; res.type('html').send(await dash.page(deps, req.query)); });
app.get('/admin-down', async (req, res) => { if (!gate.requireAdmin(req, res)) return; res.type('html').send(await dash.page(depsDown, req.query)); });
app.post('/admin/row/delete', (req, res) => { if (!gate.requireAdmin(req, res)) return; gate.ok(res, '/admin', 'ลบแล้ว'); });

const srv = app.listen(0, async () => {
  const base = 'http://127.0.0.1:' + srv.address().port;
  let pass = 0, fail = 0;
  const check = (name, cond, extra = '') => { (cond ? pass++ : fail++); console.log((cond ? 'PASS ' : 'FAIL ') + name + (cond ? '' : ' :: ' + extra)); };

  let r = await fetch(base + '/admin');
  check('ไม่ใส่ key -> 401', r.status === 401, 'got ' + r.status);
  r = await fetch(base + '/admin?key=wrong');
  check('key ผิด -> 401', r.status === 401, 'got ' + r.status);
  r = await fetch(base + '/admin?key=test-key-1234');
  check('key ยาวกว่า -> 401 (ไม่ throw)', r.status === 401, 'got ' + r.status);

  r = await fetch(base + '/admin?key=test-key-123&ok=' + encodeURIComponent('บันทึกแล้ว'));
  const html = await r.text();
  check('key ถูก -> 200', r.status === 200, 'got ' + r.status);
  check('escape XSS', !html.includes('<img src=x onerror') && html.includes('&lt;img src=x'));
  check('flash ok ขึ้น', html.includes('class="flash fok"'));
  check('นับผู้ใช้จากตารางจริง', html.includes('>370<'));
  check('ลิงก์ nav พก key', html.includes('?key=test-key-123'));
  check('ฟอร์ม POST มี hidden key', html.includes('name="key" value="test-key-123"'));
  check('ตารางย่อแถวเกิน', (html.match(/class="urow hid"/g) || []).length > 0);
  check('ไม่มี ${ ค้างใน output', !html.includes('${'));

  r = await fetch(base + '/admin-down?key=test-key-123');
  const down = await r.text();
  check('ข้อมูลล่ม -> ยัง 200', r.status === 200, 'got ' + r.status);
  check('ขึ้นคำเตือน migration', down.includes('class="warn"'));

  r = await fetch(base + '/admin/row/delete', { method: 'POST', redirect: 'manual', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: 'key=test-key-123&id=a1' });
  check('POST -> 302 กลับพร้อม flash', r.status === 302 && /ok=/.test(r.headers.get('location') || ''), r.status + ' ' + r.headers.get('location'));
  r = await fetch(base + '/admin/row/delete', { method: 'POST', redirect: 'manual', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: 'key=nope' });
  check('POST ไม่มี key -> 401', r.status === 401, 'got ' + r.status);

  console.log('\nRESULT ' + pass + ' passed / ' + fail + ' failed');
  srv.close();
  process.exit(fail ? 1 : 0);
});
