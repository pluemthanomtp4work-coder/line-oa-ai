---
name: sbu-myagent-builder
description: สร้างหน้าหลังบ้านหรือหน้า admin ของเว็บแบบไม่มี framework บนเว็บเซิร์ฟเวอร์ Node กับ Express.js - ต่อ HTML เป็นสตริง ล็อกด้วยคีย์ มีการ์ดสถิติ กราฟแท่ง ตารางค้นหาได้ และปุ่มลบ ทำได้ทั้งหน้าเดียวและชุดเต็มหลายหน้า ใช้เมื่อผู้ใช้ต้องการทำหน้า admin หน้าหลังบ้าน dashboard ดูสถิติหรือค่าใช้จ่าย หน้าจัดการผู้ใช้และสิทธิ์ หน้า monitoring ของระบบ หรือเพิ่มเมนูในหน้าหลังบ้าน
---

# SBU-MyAgent-builder — หน้าหลังบ้าน (admin) ของเว็บ (Node + Express.js ต่อ HTML เป็นสตริง)

> **"Express" ที่นี่ = Express.js เว็บเซิร์ฟเวอร์ของ Node** ไม่ใช่โปรแกรมบัญชี Express
> งานโปรแกรมบัญชี Express (FoxPro/DBF/UiPath) อยู่ที่ `express-rpa-uipath` คนละเรื่องกันสิ้นเชิง

สูตรทำหน้าหลังบ้านที่ **ขึ้นได้ใน ~1 ชั่วโมง ไม่ต้องมี build step ไม่ต้องมี React**
ต้นแบบคือหน้า `/admin` ของบอท **LINE ผู้ช่วย** (line-outlook-assistant — ใช้งานจริง ผู้ใช้ 370 คน)
แต่สูตรไม่ผูกกับ LINE เอาไปทำหลังบ้านให้โปรเจกต์เว็บตัวไหนก็ได้

ไฟล์พร้อมใช้อยู่ใน `assets/` ของ skill นี้ — **คัดลอกไปวางใน `src/` ของโปรเจกต์ปลายทางแล้วแก้ต่อ**
ทั้งชุดผ่าน smoke test 15/15 (gate 401, escape XSS, degrade เมื่อ DB ล่ม, PRG redirect)

## เมื่อไหร่ใช้ / ไม่ใช้

| ใช้ | ไม่ใช้ |
|---|---|
| หน้าหลังบ้านให้ทีมดูเอง 1-20 คน | หน้าที่ลูกค้าภายนอกเห็น (ต้องมี auth จริง) |
| เว็บ Node/Express.js ที่ไม่มี frontend build | โปรเจกต์ที่มี Next.js/React อยู่แล้ว |
| ต้องการ ship เร็ว แก้ที่เดียวเห็นผลทันที | หน้าที่ต้อง interactive หนัก (drag/realtime) |

## ขั้นตอน (ทำตามลำดับนี้)

### 1. วางไฟล์ฐาน 3 ตัว (ครั้งเดียวต่อโปรเจกต์)
```bash
cp ~/.claude/skills/sbu-myagent-builder/assets/{uiTheme.js,adminNav.js,adminGate.js} src/
```
- `uiTheme.js` — โทเคนสี/ฟอนต์ + CSS คอมโพเนนต์กลาง (`.panel .btn .stat .tablecard .flash .warn .chip`)
- `adminNav.js` — รายการแท็บ **แหล่งความจริงเดียว** เพิ่มหน้าใหม่ = เพิ่มแถวใน `TABS`
- `adminGate.js` — ด่าน `?key=`, `keyInput()`, `ok()/err()` redirect, `flashHtml()`

ตั้ง `ADMIN_KEY` ใน `.env` (สุ่มยาว ≥ 24 ตัว) และใส่ `.env.example` ด้วย

### 2. คัดลอกหน้า dashboard เป็นตัวตั้งต้น
```bash
cp ~/.claude/skills/sbu-myagent-builder/assets/dashboardPage.js src/adminPage.js
```
แล้วแก้ `deps` ให้ชี้ไปที่ layer ข้อมูลจริงของโปรเจกต์

### 3. ต่อ route ใน `index.js`
```js
const express = require('express');
app.use(express.urlencoded({ extended: false }));   // ← ขาดตัวนี้ req.body = undefined → POST เด้ง 401 ทุกครั้ง

const gate = require('./adminGate');
const adminPage = require('./adminPage');

app.get('/admin', async (req, res) => {
  if (!gate.requireAdmin(req, res)) return;
  try { res.type('html').send(await adminPage.page(deps, req.query)); }
  catch (e) { console.error('[admin]', e); res.status(500).send('โหลดหน้าไม่ได้'); }
});

app.post('/admin/row/delete', async (req, res) => {
  if (!gate.requireAdmin(req, res)) return;
  try { await db.deleteRow(req.body.id); return gate.ok(res, '/admin', 'ลบแล้ว'); }
  catch (e) { return gate.err(res, '/admin', 'ลบไม่สำเร็จ: ' + e.message); }
});
```

### 4. โครงหน้าที่ต้องรักษาไว้ (เรียงจากบนลงล่าง)
```
hero (h1 + hsub + pill สถานะ) + nav แท็บ
 └ wrap.lift
    flash (ok/err จาก query)  →  warn (ตารางยังไม่ถูกสร้าง)
    .stats     4 การ์ดตัวเลขสรุป
    .panels    กราฟ/ตัวชี้วัด (grid auto-fit)
    .tablecard ตารางรายละเอียด + ช่องค้นหา + ปุ่ม "แสดงทั้งหมด"
    <details class="fold">  ของที่ใช้นานๆ ครั้ง (ฟอร์มตั้งค่า, ล็อก, แกลเลอรี)
    footer     บอกที่มาของตัวเลข + ข้อจำกัด
```

### 5. แยกสองชั้นเสมอ — `page()` ดึงข้อมูล / `render(m)` สร้าง string
`render` ต้องเป็น pure ไม่ `await` ไม่แตะ DB → เทสต์ด้วยข้อมูลปลอมได้โดยไม่ต้องมี DB
`page()` ยิงทุก query ใน `Promise.all` และ **ทุกตัวมี `.catch` ของตัวเอง**

### 6. เทสต์ก่อนส่ง
```bash
cp ~/.claude/skills/sbu-myagent-builder/assets/smoke.example.js test/admin.smoke.js
node test/admin.smoke.js      # ต้องได้ 15 passed / 0 failed
```
ยิงจริงผ่าน HTTP ไม่ต้องมี DB — ครอบ: ไม่มี key→401 · key ผิด→401 · key ยาวกว่า→401 (ไม่ throw) ·
key ถูก→200 · payload XSS ถูก escape · แหล่งข้อมูลล่ม→ยัง 200 + ขึ้นคำเตือน · POST→302 กลับพร้อม flash

## กับดักที่เสียเวลาไปแล้ว

- **นับ "ผู้ใช้ทั้งหมด" จากตาราง log** → ได้แค่คนที่ใช้งานในช่วงนั้น (เคยโชว์ 183 ทั้งที่มีจริง 370)
  นับจากตารางผู้ใช้จริงเสมอ ถ้านับไม่ได้ค่อยถอยไปใช้เลขจาก log **แล้วติดป้ายว่าเป็นค่าประมาณ**
- **ลืม `esc()` แม้ช่องเดียว = XSS** ชื่อ/อีเมล/หมายเหตุที่ผู้ใช้พิมพ์เองเข้ามาทาง DB ได้ทั้งนั้น
  ครอบ `esc()` ทุกค่าที่ไม่ใช่ตัวเลขที่เราคำนวณเอง
- **`.catch(() => [])` กับ `.catch(() => null)` ไม่เหมือนกัน** — คืน `null` แปลว่า "ยังไม่ได้ตั้งค่า/ตารางยังไม่มี"
  แล้ว render แสดง "⚠️ รัน migration ก่อน"; คืน `[]` แปลว่า "มีตารางแต่ยังไม่มีข้อมูล" คนละข้อความกัน
  ถ้าใช้ `[]` ทั้งคู่ ติดตั้งใหม่จะเห็นหน้าเปล่าแล้วนึกว่าพัง
- **grid ล็อก `repeat(2,1fr)`** พอมีการ์ดที่ 3 มันตกลงมาอยู่เดี่ยวๆ ครึ่งแถว
  ใช้ `repeat(auto-fit,minmax(300px,1fr))` + `align-items:start` (ไม่งั้นการ์ดเตี้ยถูกยืดตามการ์ดสูง เหลือที่ว่างกลางการ์ด)
- **ตารางยาวเกิน 15 แถวทำให้หน้าใช้ไม่ได้** ซ่อนส่วนเกินด้วยคลาส `.hid` + ปุ่มกาง + ช่องค้นหาฝั่ง browser
  (ใส่ `data-hay="ชื่อ ตัวพิมพ์เล็ก"` ในแต่ละ `<tr>` — ไม่ต้องยิงเซิร์ฟเวอร์ใหม่ตอนค้น)
- **ฟอร์มที่ใช้เดือนละครั้งกินพื้นที่หัวหน้าตลอด** ยัดใน `<details class="fold">` ปิดไว้ก่อน
- **CSS เฉพาะหน้าที่เขียนเป็น class เดี่ยวจะแพ้ `BASE_CSS`** เพราะในนั้นจัดสไตล์ input ด้วย
  `input[type=search]` (specificity สูงกว่า `.srch`) → ช่องค้นหากว้าง 100% ดันหัวตารางตกบรรทัด
  เขียนเป็น `input[type=search].srch{width:auto}` แทน (เจอตอนถ่ายภาพหน้าจริง ไม่เจอจากการอ่านโค้ด)
- **แถบ progress ต้องเทียบกับอะไรที่มีความหมาย** เคยใส่ `calls/10` เป็นตัวหาร ได้แถบว่างเปล่า 2%
  ที่ดูเหมือนระบบพัง — เทียบกับเพดานจริง (โควต้า/งบ/ค่าสูงสุดต่อวัน) เท่านั้น
- **ดูด้วยตาก่อนส่งเสมอ** เทสต์ผ่านหมดแต่หน้าเบี้ยวได้ ถ่ายภาพจริงด้วย Chrome ที่มีในเครื่อง:
  `"C:/Program Files/Google/Chrome/Application/chrome.exe" --headless=new --disable-gpu --hide-scrollbars --window-size=1280,1400 --screenshot=shot.png "file:///.../out.html"`
  (เขียน HTML ลงไฟล์จาก `render()` ตรงๆ ไม่ต้องรันเซิร์ฟเวอร์)
- **`confirm()` ใน `onsubmit` ที่อยู่ใน template literal** ต้องเขียน `\\n` (สอง backslash) ไม่งั้นได้ newline จริงกลาง
  attribute แล้ว HTML พัง — และให้ list เป็นภาษาไทยว่า **อะไรจะหาย / อะไรไม่หาย**
- **`meta http-equiv="refresh"` ล้างสิ่งที่ผู้ใช้กำลังพิมพ์** ใส่ได้เฉพาะหน้าที่เป็น monitoring ล้วน
  หน้าที่มีฟอร์มยาว (แก้ข้อความ/อัปโหลด) ห้ามใส่
- **`timingSafeEqual` โยน error ถ้าความยาวไม่เท่ากัน** ต้องเช็ค `a.length === b.length` ก่อนเสมอ (มีใน `adminGate.js` แล้ว)
- **`?key=` ไม่ใช่ auth จริง** — มันติดไปกับ URL, referrer, log ของ proxy และประวัติเบราว์เซอร์
  อย่าวางข้อมูลที่หลุดไม่ได้ (token, ข้อมูลลูกค้าเต็มรูปแบบ) ในหน้าที่ล็อกด้วยวิธีนี้ ถ้าต้องการจริงให้ทำ session
- **ฟอนต์**: หน้าเว็บใช้ IBM Plex Sans Thai (โหลดจาก Google Fonts) — คนละเรื่องกับกฎ FC Minimal/TH Sarabun
  ที่ใช้ตอนเรนเดอร์ภาพ/PDF อย่าเอามาปนกัน

## เรื่องเงิน (ถ้าหน้านี้โชว์ค่าใช้จ่าย API)

- คิดเป็น **USD ก่อน** ตามเรตของโมเดลที่ใช้จริงในแต่ละ call (เก็บ `model` ลง log ด้วย) แล้วค่อยแปลงบาท
  ตอนแสดงผล — เรตเดียวรวมทุกโมเดลคลาดเคลื่อนหลายเท่า (flash vs flash-lite ต่างกัน ~6 เท่า)
- **output tokens = total − prompt** ไม่ใช่ `candidate_tokens` เพราะ Gemini คิดเงิน thinking tokens
  ที่เรต output แต่ไม่นับรวมใน candidates
- ตัวเลขในหน้า = "เท่าที่ log ไว้" เสมอ ไม่เท่าบิลจริง (สคริปต์ทดสอบ/dev ไม่ผ่าน log)
  ทำช่องกรอกยอดบิลจริง + โชว์ส่วนต่าง แล้วเขียนกำกับใน footer ว่าตัวเลขมาจากไหน

## ไฟล์ในโฟลเดอร์นี้

| ไฟล์ | ใช้ทำอะไร |
|---|---|
| `assets/uiTheme.js` | โทเคน + CSS กลาง — คัดลอกไปทั้งไฟล์ แก้เฉพาะสี accent |
| `assets/adminNav.js` | แท็บเมนู — แก้ `TABS` ให้ตรงหน้าที่มีจริง |
| `assets/adminGate.js` | `?key=` gate, hidden key input, PRG redirect + flash |
| `assets/dashboardPage.js` | หน้า dashboard เต็ม (stats/กราฟ/ตารางค้นหา/fold) — ตัวตั้งต้นที่รันได้จริง |
| `references/checklist.md` | เช็คลิสต์ก่อนส่งงาน + สูตรส่วนประกอบเพิ่มเติม (แกลเลอรีรูป, ชิปกรอง, กราฟแท่ง) |
| `references/pages.md` | **สเปกหน้าหลังบ้านชุดเต็ม 8 หน้า** — อ่านเมื่อผู้ใช้บอกว่า "ทำให้ครบทุกหน้า" |
